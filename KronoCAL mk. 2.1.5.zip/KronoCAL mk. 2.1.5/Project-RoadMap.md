BOLD ITEMS ARE COMPLETED
1. **Create an (*.html) "GUI".**
2. **Create a JavaSctipt sheet for calendar support & functionality.**
<!--ongoing-->
3. Add in Features {
    Fully editable event planning <!--This should include 'after-the-fact' edits-->
    MSFT To-Do API using Graph
    Outlook Calendar API Integration
    Google Calendar API Integration
    Tiered Priority settings
    Attendee settings    
} 
    
4. 
