


const { Client } = require('pg');

const client = new Client({
  host: 'setting',
  port: 5432,
  user: 'postgres',
  password: '5taticPassInfo',
  database: 'kronocal'
});

client.connect(err => {
  if (err) {
    console.error('Connection error', err.stack);
  } else {
    console.log('Connected to the database');
  }
});

